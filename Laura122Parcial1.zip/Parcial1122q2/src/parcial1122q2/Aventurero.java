
package parcial1122q2;

import java.util.Objects;


public abstract class Aventurero{
    
    private String codIdentificacion;
    private String nombre;
    private Rango rango;

    
    /**
     * cree el constructor con los atributos declarados.
     * @param codIdentificacion de tipo string.
     * @param nombre de tipo string.
     * @param rango de tipo Rango.
     */
    public Aventurero(String codIdentificacion, String nombre, Rango rango) {
        this.codIdentificacion = codIdentificacion;
        this.nombre = nombre;
        this.rango = rango;
        validarNull();
    }

    
    /**
     * cree los getters para que desde el main.
     * @return 
     */
    public String getCodIdentificacion() {
        return codIdentificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public Rango getRango() {
        return rango;
    }
    
    
    /**
     * cree el metodo validarnull para q no sea nulo.
     * que codIdentificacion y nombre no esten en blanco.
     * en caso que se cumpla con la condicion le lanzo una exception.
     */
    public void validarNull(){
        if(codIdentificacion == null || codIdentificacion.isBlank()){
            throw new IllegalArgumentException("El codigo de identificacion no puede ser nulo ni estar en blanco.");
        }
        if(nombre == null || nombre.isBlank()){
            throw new IllegalArgumentException("El nombre no puede ser nulo ni estar en blanco.");
        }
        if(rango == null){
            throw new IllegalArgumentException("El rango no puede ser nulo.");
        }
    }


    @Override
    public int hashCode() {
        return Objects.hash(this.codIdentificacion, this.nombre);
    }

    @Override
    public boolean equals(Object obj){
        if(obj == null){
            return false;
        }
        if(obj == this){
            return true;
        }
        if(obj instanceof Aventurero otro){
            return(nombre.equals(otro.nombre) && codIdentificacion.equals(otro.codIdentificacion));
        }
        return false;
    }
    
    
    public abstract void atacar();
    
    public abstract int getPoderCombate();

    @Override
    public String toString() {
        return "Aventurero[" + "codIdentificacion= " + codIdentificacion + ", nombre= " + nombre + ", rango= " + rango + " poder de combate= " + getPoderCombate() + ']';
    }
    
    
}
